package com.lyz.scale.demo.module_print;

import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android_serialport_api.SerialPort;


/**
 * 工具类
 * Created by Test on 5/14/2018.
 */

public class SerialPortUtilForPrint {
    public static SerialPort mSerialPort;
    public static InputStream mInputStream;
    public static OutputStream mOutputStream;
    public static boolean isOpen = false;

    private String prot = "ttyS3";//4
    private int baudrate = 9600;

    private SerialPortUtilForPrint() {}

    public void OpenSerialPort() {
        try {
            mSerialPort = new SerialPort(new File("/dev/" + prot), baudrate,
                    0);
            mInputStream = mSerialPort.getInputStream();
            mOutputStream = mSerialPort.getOutputStream();

            isOpen = true;
        } catch (SecurityException e) {
            e.printStackTrace();
        } catch (IOException e) {
            Log.i("test", "打开失败");
            e.printStackTrace();
        }
    }

    private static SerialPortUtilForPrint singleTon = null;

    public static SerialPortUtilForPrint Instance()
    {
        if(null == singleTon)
            singleTon = new SerialPortUtilForPrint();
        return  singleTon;
    }

    /**
     * 关闭串口
     */
    public void CloseSerialPort() {

        if (mSerialPort != null) {
            mSerialPort.close();
        }
        if (mInputStream != null) {
            try {
                mInputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (mOutputStream != null) {
            try {
                mOutputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        isOpen = false;
    }

}
