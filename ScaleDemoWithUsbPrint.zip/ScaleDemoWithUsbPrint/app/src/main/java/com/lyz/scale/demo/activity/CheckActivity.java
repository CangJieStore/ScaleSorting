package com.lyz.scale.demo.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.lyz.scale.demo.R;
import com.lyz.scale.demo.module_scale.ScaleModule;

import java.util.ArrayList;
import java.util.List;

public class CheckActivity extends Activity implements View.OnClickListener {

    private TextView mStep1;
    private TextView mStep2;
    private TextView mStep3;
    private TextView mStep4;
    private TextView mCheckTitle;
    private TextView mCheckContent;
    private TextView mCheckIndication;
    private TextView mCheckWeightLabel;
    private EditText mCheckWeightNum;
    private Button mBtnNext;

    private int mCurrentStep = 0;
    private List<TextView> mSteps;
    private List<String> mTitles;
    private List<String> mContents;

    private ScaleModule scaleModule;

    private static final String TAG = "MainCheckLog";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check);

        initViews();
        initSteps();
        try {
            scaleModule = ScaleModule.Instance(CheckActivity.this);
        } catch (Exception e) {
            DisplayError(R.string.check_init_error);
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void DisplayError(int resourceId) {
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("Error");
        b.setMessage(resourceId);
        b.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                CheckActivity.this.finish();
            }
        });
        b.show();
    }

    private void initSteps() {
        mCurrentStep = 0;
        mSteps = new ArrayList<>();
        mSteps.add(mStep1);
        mSteps.add(mStep2);
        mSteps.add(mStep3);
        mSteps.add(mStep4);
        mTitles = new ArrayList<>();
        mTitles.add(getResources().getString(R.string.check_title_1));
        mTitles.add(getResources().getString(R.string.check_title_2));
        mTitles.add(getResources().getString(R.string.check_title_3));
        mTitles.add(getResources().getString(R.string.check_title_4));
        mContents = new ArrayList<>();
        mContents.add(getResources().getString(R.string.check_content_1));
        mContents.add(getResources().getString(R.string.check_content_2));
        mContents.add(getResources().getString(R.string.check_content_3));
        mContents.add(getResources().getString(R.string.check_content_4));
    }

    private void initViews() {
        mStep1 = (TextView) findViewById(R.id.step_1);
        mStep2 = (TextView) findViewById(R.id.step_2);
        mStep3 = (TextView) findViewById(R.id.step_3);
        mStep4 = (TextView) findViewById(R.id.step_4);
        mCheckTitle = (TextView) findViewById(R.id.check_title);
        mCheckContent = (TextView) findViewById(R.id.check_content);
        mCheckIndication = (TextView) findViewById(R.id.check_indication);
        mCheckWeightLabel = (TextView) findViewById(R.id.check_weight);
        mCheckWeightNum = (EditText) findViewById(R.id.check_weight_num);
        mBtnNext = (Button) findViewById(R.id.check_next);
        findViewById(R.id.back).setOnClickListener(this);
        mBtnNext.setOnClickListener(this);
    }

    private void goBack() {
        finish();
    }

    private void goNext() {
        System.out.println(TAG+"***********go next begin************");
        System.out.println(TAG+"mCurrentStep = " + mCurrentStep);
        if (mCurrentStep == 3) {
            Toast.makeText(this, "校准完成", Toast.LENGTH_SHORT).show();
            new Handler().postDelayed(new finishHandler(), 2000); // 延迟1秒，再运行finishHandler
            return;
        }
        mSteps.get(mCurrentStep).setTextColor(getResources().getColor(R.color.text_color));
        mCurrentStep++;
        mSteps.get(mCurrentStep).setTextColor(getResources().getColor(R.color.theme_color));
        mCheckTitle.setText(mTitles.get(mCurrentStep));
        mCheckContent.setText(mContents.get(mCurrentStep));
        setInputWeight();
        if (mCurrentStep == 3) {
            mBtnNext.setText("完 成");
        } else {
            mBtnNext.setText("下一步");
        }
        try {
            switch (mCurrentStep) {
                case 1:
                    scaleModule.SetDeadLoadWeight();
                    Log.e(TAG, "send set zero command");
                    break;
                case 2:
                    Log.e(TAG, "place the weighter to the board");
                    break;
                case 3:
                    scaleModule.SetFullLoadWeight(Double.parseDouble(mCheckWeightNum.getText().toString().trim()));
                    Log.e(TAG, "send the full weight command");
                    break;
            }

        }catch (Exception e){
            DisplayError(R.string.check_setting_error);
            e.printStackTrace();
        }
    }

    private void setInputWeight() {
        if (mCurrentStep == 2) {
            mCheckIndication.setVisibility(View.GONE);
            mCheckWeightLabel.setVisibility(View.VISIBLE);
            mCheckWeightNum.setVisibility(View.VISIBLE);
        } else {
            mCheckIndication.setVisibility(View.GONE);
            mCheckWeightLabel.setVisibility(View.GONE);
            mCheckWeightNum.setVisibility(View.GONE);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.check_next:
                goNext();
                break;
            case R.id.back:
                goBack();
                break;
        }
    }

    private class finishHandler implements Runnable {
        @Override
        public void run() {
            finish();
        }
    }

}

