package com.lyz.scale.demo.activity;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.lyz.scale.demo.R;
import com.lyz.scale.demo.common.CommonDialog;
import com.lyz.scale.demo.utils.FormatUtil;
import com.lyz.scale.demo.module_scale.SerialPortUtilForScale;
import com.lyz.scale.demo.module_scale.ScaleModule;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "Main";

    private Context mContext;
    private TextView mTvWeight;
    private TextView mTvUnit;
    private Button mTareBtn;
    private TextView mTareWeight;
    public static String mCurrentUnit = "Kg";

    private ReadDataReceiver readDataReceiver;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = this;
        mTvUnit = (TextView) findViewById(R.id.tv_unit);
        mTvUnit.setText("重量（" + mCurrentUnit + "）：");
        mTvWeight = (TextView) findViewById(R.id.tv_weight);
        mTareWeight = (TextView) findViewById(R.id.tv_tare_weight);
        findViewById(R.id.btn_goto_usb_print).setOnClickListener(this);
        findViewById(R.id.btn_check).setOnClickListener(this);
        findViewById(R.id.btn_zero).setOnClickListener(this);
        mTareBtn = (Button) findViewById(R.id.btn_clear_tare);
        mTareBtn.setOnClickListener(this);
        findViewById(R.id.btn_setting).setOnClickListener(this);
        findViewById(R.id.btn_goto_print).setOnClickListener(this);
        new Thread(new Runnable() {
            @Override
            public void run() {
                SerialPortUtilForScale.Instance().OpenSerialPort();//打开称重串口
                try {
                    ScaleModule.Instance(mContext);//初始化称重模块
                } catch (Exception e) {
                    e.printStackTrace();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            CommonDialog dialog = new CommonDialog(mContext);
                            dialog.setTextView("初始化称重主板错误！");
                            dialog.setCanceledOnTouchOutside(true);
                            dialog.show();
                        }
                    });

                }

            }
        }).start();
        readDataReceiver = new ReadDataReceiver();
        registerReceiver(readDataReceiver, new IntentFilter(ScaleModule.WeightValueChanged));
        registerReceiver(readDataReceiver, new IntentFilter(ScaleModule.ERROR));

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(readDataReceiver);
        SerialPortUtilForScale.Instance().CloseSerialPort();//关闭称重串口
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_goto_usb_print://跳转到USB打印测试页面
                startActivity(new Intent(mContext, UsbPrintTestActivity.class));
                break;
            case R.id.btn_goto_print://跳转到测试打印页面
                Intent intent_print = new Intent(mContext, TestPrintActivity.class);
                startActivity(intent_print);
                break;
            case R.id.btn_check://电子秤校准
                inputPwdEnter("admin", CheckActivity.class);
                break;
            case R.id.btn_zero://置零
                try {
                    ScaleModule.Instance(this).ZeroClear();
                } catch (Exception ee) {
                    ee.printStackTrace();
                    Log.e(TAG, ee.getMessage());
                }
                break;
            case R.id.btn_clear_tare://去皮
                try {
                    if ("去皮".equals(mTareBtn.getText().toString().trim())) {
                        ScaleModule.Instance(this).ClearTare();
                        mTareBtn.setText("清皮");
                    } else {
                        ScaleModule.Instance(this).TareClear();
                        mTareBtn.setText("去皮");
                    }
                    updateWeight();
                } catch (Exception ee) {
                    ee.printStackTrace();
                    Log.e(TAG, ee.getMessage());
                }
                break;
            case R.id.btn_setting://设置
                inputPwdEnter("admin", AdvanceSettings.class);
                break;
        }
    }

    private void inputPwdEnter(final String password, final Class enterActivity) {
        LayoutInflater factory = LayoutInflater.from(mContext);//提示框
        final View view = factory.inflate(R.layout.dialog_input_pwd, null);//这里必须是final的
        final EditText edit = (EditText) view.findViewById(R.id.editText);//获得输入框对象
        new AlertDialog.Builder(mContext)
                .setTitle("请输入密码")//提示框标题
                .setView(view)
                .setPositiveButton("确定",//提示框的两个按钮
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                //验证密码进入设置
                                String pwd = edit.getText().toString().trim();
                                if (password.equals(pwd)) {
                                    Intent intent_setting = new Intent(mContext, enterActivity);
                                    startActivity(intent_setting);
                                } else {
                                    Toast.makeText(mContext, "请输入正确的密码", Toast.LENGTH_SHORT).show();
                                    edit.setText("");
                                }
                            }
                        }).setNegativeButton("取消", null).create().show();
    }

    private class ReadDataReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (ScaleModule.ERROR.equals(intent.getAction())) {
                String error = intent.getStringExtra("error");
                new AlertDialog.Builder(mContext)
                        .setTitle("错误提示")//提示框标题
                        .setMessage(error)
                        .setPositiveButton("确定",//提示框的两个按钮
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog,
                                                        int which) {
                                        dialog.dismiss();
                                    }
                                })
                        .create()
                        .show();
            } else {
                updateWeight();
            }
        }
    }

    private void updateWeight() {
        try {
            mTvWeight.setText(FormatUtil.roundByScale(
                    (ScaleModule.Instance(mContext).RawValue - ScaleModule.Instance(mContext).TareWeight),
                    ScaleModule.Instance(mContext).SetDotPoint));
            mTareWeight.setText(FormatUtil.roundByScale(ScaleModule.Instance(mContext).TareWeight,
                    ScaleModule.Instance(mContext).SetDotPoint));
        } catch (Exception ee) {
            ee.printStackTrace();
            Log.e(TAG, ee.getMessage());
        }
    }
}
