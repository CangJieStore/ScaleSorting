package com.lyz.scale.demo.activity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.lyz.scale.demo.R;
import com.lyz.scale.demo.module_scale.ScaleModule;
import com.lyz.scale.demo.widget.MySpinner;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuyuzhi.
 */

public class AdvanceSettings extends BaseActivity {

    private static final String TAG = "MainAdvanceSettings";
    private MySpinner spinner_dot,spinner_volume,spinner_uint;
    private EditText setting_max;
    private Context mContext;

    private MySpinner spinner_filter,spinner_zero_track,spinner_zero_hand,spinner_zero_start,spinner_sample_rate;

    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        setContentView(R.layout.activity_advance_settings);
        mContext = this;

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        spinner_dot = (MySpinner) findViewById(R.id.dot_count_setting);
        spinner_dot.setText("小数点位数");
        spinner_volume = (MySpinner) findViewById(R.id.volume_setting);
        spinner_volume.setText("分度值设置");
        setting_max = (EditText) findViewById(R.id.setting_max);
        spinner_uint = (MySpinner) findViewById(R.id.uint_setting);
        spinner_uint.setText("计量单位");

        spinner_filter = (MySpinner) findViewById(R.id.setting_filter);
        spinner_filter.setText("滤波强度");
        spinner_zero_track = (MySpinner) findViewById(R.id.setting_track);
        spinner_zero_track.setText("零点跟踪范围");
        spinner_zero_hand = (MySpinner) findViewById(R.id.setting_zero_hand);
        spinner_zero_hand.setText("手动置零范围");
        spinner_zero_start = (MySpinner) findViewById(R.id.setting_zero_start);
        spinner_zero_start.setText("开机置零范围");
        spinner_sample_rate = (MySpinner) findViewById(R.id.setting_sample_rate);
        spinner_sample_rate.setText("采样速率");

        initData();
        try {
            spinner_dot.setSelection(ScaleModule.Instance(this).SetDotPoint);
            spinner_volume.setSelection(String.valueOf(ScaleModule.Instance(this).SetDevision));
            spinner_uint.setSelection(ScaleModule.Instance(this).SetUint - 1);
            spinner_filter.setSelection(ScaleModule.Instance(this).SetFilter - 1);
            spinner_zero_track.setSelection(ScaleModule.Instance(this).SetZeroTrace - 1);
            spinner_zero_hand.setSelection(ScaleModule.Instance(this).SetZeroByHand - 1);
            spinner_zero_start.setSelection(ScaleModule.Instance(this).SetZeroByStart -1);
            spinner_sample_rate.setSelection(ScaleModule.Instance(this).SetSampleRate - 1);

            setting_max.setText(String.valueOf(ScaleModule.Instance(mContext).SetMaxWeight));
        }catch (Exception e){
            e.printStackTrace();
            Log.e(TAG, "onCreate: error : "+e.getMessage());
            Toast.makeText(this,"ERROR:"+e.getMessage(),Toast.LENGTH_SHORT).show();
        }

        findViewById(R.id.save_setting).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //点击保存按钮；
                int dot = spinner_dot.getSelectionIndex();
                int volume = Integer.parseInt(spinner_volume.getSelectionValue());
                int uint = spinner_uint.getSelectionIndex() + 1;
                int filter = spinner_filter.getSelectionIndex() + 1;
                int track = spinner_zero_track.getSelectionIndex() + 1;
                int hand = spinner_zero_hand.getSelectionIndex() + 1;
                int start = spinner_zero_start.getSelectionIndex() + 1;
                int rate = spinner_sample_rate.getSelectionIndex() + 1;
                double maxWeight = Double.parseDouble(setting_max.getText().toString().trim());

                Log.d("Main--AdvanceSettings", "save: "+dot+","+volume+","+uint+","
                        +filter+","+track+","+hand+","+start+","+rate);
                try {
                    ScaleModule.Instance(mContext).SetDotPoint = dot;
                    ScaleModule.Instance(mContext).SetDevision = volume;
                    ScaleModule.Instance(mContext).SetUint = uint;
                    ScaleModule.Instance(mContext).SetFilter = filter;
                    ScaleModule.Instance(mContext).SetZeroTrace = track;
                    ScaleModule.Instance(mContext).SetZeroByHand = hand;
                    ScaleModule.Instance(mContext).SetZeroByStart = start;
                    ScaleModule.Instance(mContext).SetSampleRate = rate;

                    ScaleModule.Instance(mContext).Save_DotPoint(dot);
                    Thread.sleep(50);
                    ScaleModule.Instance(mContext).Save_Devision(volume);
                    Thread.sleep(50);
                    ScaleModule.Instance(mContext).Save_Uint(uint);
                    Thread.sleep(50);
                    ScaleModule.Instance(mContext).Save_Filter(filter);
                    Thread.sleep(50);
                    ScaleModule.Instance(mContext).Save_ZeroTrace(track);
                    Thread.sleep(50);
                    ScaleModule.Instance(mContext).Save_ZeroRange_Hand(hand);
                    Thread.sleep(50);
                    ScaleModule.Instance(mContext).Save_ZeroRange_Start(start);
                    Thread.sleep(50);
                    ScaleModule.Instance(mContext).Save_SampleRate(rate);
                    Thread.sleep(50);
                    ScaleModule.Instance(mContext).Save_MaxWeight(maxWeight);

                    Toast.makeText(mContext,"参数保存成功",Toast.LENGTH_SHORT).show();

                } catch (Exception e){
                    e.printStackTrace();
                    Log.d(TAG, "onClick: error"+e.getMessage());
                    Toast.makeText(mContext,"ERROR:"+e.getMessage(),Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void initData(){
        List<String> data = new ArrayList<>();
        data.add("无小数点");
        data.add("1位");
        data.add("2位");
        data.add("3位");
        spinner_dot.updateData(data);
        data.clear();
        data.add("1");
        data.add("2");
        data.add("5");
        data.add("10");
        data.add("20");
        data.add("50");
        spinner_volume.updateData(data);
        data.clear();
        data.add("Kg");
        data.add("lb");
        spinner_uint.updateData(data);
        data.clear();
        data.add("弱");
        data.add("中");
        data.add("强");
        spinner_filter.updateData(data);
        data.clear();
        data.add("0.5d");
        data.add("1d");
        data.add("1.5d");
        data.add("2d");
        data.add("2.5d");
        data.add("3d");
        data.add("3.5d");
        data.add("禁止追踪");
        spinner_zero_track.updateData(data);
        data.clear();
        data.add("2%");
        data.add("4%");
        data.add("10%");
        data.add("20%");
        data.add("100%");
        data.add("禁止置零");
        spinner_zero_hand.updateData(data);
        spinner_zero_start.updateData(data);
        data.clear();
        data.add("低采样速率");
        data.add("高采样速率");
        spinner_sample_rate.updateData(data);
        data.clear();
    }
}
