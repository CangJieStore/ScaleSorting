package com.lyz.scale.demo.widget;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.lyz.scale.demo.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuyuzhi.
 */

public class MySpinner extends LinearLayout{

    private TextView mLabel;
    private Spinner mSpinner;
    private CommonAdapter<String> adapter;
    private List<String> mData = new ArrayList<>();

    public MySpinner(Context context) {
        super(context);
        initMySpinner(context);
    }

    public MySpinner(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initMySpinner(context);
    }

    public MySpinner(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initMySpinner(context);
    }

    public void setSelection(int index){
        mSpinner.setSelection(index);
    }

    public void setSelection(String value){
        for (int i = 0;i<mData.size();i++){
            String volume = mData.get(i);
            if (volume.equals(value)){
                mSpinner.setSelection(i);
                break;
            }
        }
    }

    public String getSelectionValue(){
        return mSpinner.getSelectedItem().toString();
    }

    public int getSelectionIndex(){
        return mSpinner.getSelectedItemPosition();
    }

    public void setText(String text){
        mLabel.setText(text);
    }

    public List<String> getData() {
        return mData;
    }

    public void updateData(List<String> data){
        mData.clear();
        mData.addAll(data);
        adapter.notifyDataSetChanged();
    }

    private void initMySpinner(Context context){
        LayoutInflater.from(context).inflate(R.layout.layout_widget_spinner, this, true);
        mLabel = (TextView) findViewById(R.id.label);
        mSpinner = (Spinner) findViewById(R.id.spinner);

        //将可选内容与ArrayAdapter连接起来
        adapter = new CommonAdapter<String>(context,mData,R.layout.item_spinner_dropdown) {
            @Override
            public void convert(ViewHolder holder, String s) {
                holder.setText(R.id.text,s);
            }
        };

        //设置下拉列表的风格
//        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        //将adapter 添加到spinner中
        mSpinner.setAdapter(adapter);

        //添加事件Spinner事件监听
//        mSpinner.setOnItemSelectedListener(new SpinnerSelectedListener());

        //设置默认值
//        mSpinner.setVisibility(View.VISIBLE);
    }
}
