package com.lyz.scale.demo.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.provider.Settings;


/**
 * Created by Test on 7/9/2018.
 */

public class BaseActivity extends Activity {


    private void showDialog() {
        new AlertDialog.Builder(this)
                .setTitle("温馨提示")
                .setMessage("未检测到网络连接，请插入网线或去设置WIFI！")
                .setCancelable(false)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(Settings.ACTION_WIFI_SETTINGS);
                        startActivity(intent);
                        dialog.dismiss();
                    }
                })
                .show();
    }

}