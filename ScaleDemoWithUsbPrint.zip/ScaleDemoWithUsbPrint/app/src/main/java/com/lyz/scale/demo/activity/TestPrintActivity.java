package com.lyz.scale.demo.activity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;

import com.lyz.scale.demo.R;
import com.lyz.scale.demo.common.CommonDialog;

import com.lyz.scale.demo.module_print.PrintModule;
import com.lyz.scale.demo.module_print.SerialPortUtilForPrint;

/**
 * Created by liuyuzhi.
 */

public class TestPrintActivity extends Activity {

    private String TAG = "MainTestPrint";
    private Context mContext;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_test_print);
        mContext = this;
        new Thread(new Runnable() {
            @Override
            public void run() {
                SerialPortUtilForPrint.Instance().OpenSerialPort();//打开打印串口
                try {
                    PrintModule.Instance(mContext);//初始化打印模块
                } catch (Exception e) {
                    e.printStackTrace();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            CommonDialog dialog = new CommonDialog(mContext);
                            dialog.setTextView("初始化打印模块错误！");
                            dialog.setCanceledOnTouchOutside(true);
                            dialog.show();
                        }
                    });
                }

            }
        }).start();
        findViewById(R.id.btn_print).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                testPrint();
            }
        });
    }

    private void testPrint() {
        //实现测试打印功能
        Log.d(TAG, "testPrint: begin\n");
        try {
            PrintModule.Instance(mContext).SendPrintCMD("SIZE 60 mm,60 mm\n");
            PrintModule.Instance(mContext).SendPrintCMD("GAP 2 mm,0 mm\n");
            PrintModule.Instance(mContext).SendPrintCMD("OFFSET 0 mm\n");
            PrintModule.Instance(mContext).SendPrintCMD("SPEED 3\n");
            PrintModule.Instance(mContext).SendPrintCMD("DENSITY 7\n");
            PrintModule.Instance(mContext).SendPrintCMD("SHIFT 0\n");
            PrintModule.Instance(mContext).SendPrintCMD("DIRECTION 0\n");
            PrintModule.Instance(mContext).SendPrintCMD("CLS\n");

            /* 1mm = 8 point */
            PrintModule.Instance(mContext).SendPrintCMD("TEXT 80,40,\"TSS24.BF2\",0,1,2, \"119-南熏门桥店\"\n");
            PrintModule.Instance(mContext).SendPrintCMD("QRCODE 80,80,L,6,A,0,1,7,\"二维码内容\"\n");

            PrintModule.Instance(mContext).SendPrintCMD("TEXT 40,360,\"TSS24.BF2\",0,1,2, \"西班牙土豆\"\n");
            PrintModule.Instance(mContext).SendPrintCMD("TEXT 200,400,\"TSS24.BF2\",0,1,2, \"200Kg\"\n");

            PrintModule.Instance(mContext).SendPrintCMD("PRINT 1\n");
            PrintModule.Instance(mContext).SendPrintCMD("EOP\n");


        } catch (Exception ee) {
            ee.printStackTrace();
            Log.e(TAG, "testPrint: error message : "+ee.getMessage() );
        }
    }

    @Override
    protected void onDestroy() {
        SerialPortUtilForPrint.Instance().CloseSerialPort();//关闭打印串口
        super.onDestroy();
    }
}
