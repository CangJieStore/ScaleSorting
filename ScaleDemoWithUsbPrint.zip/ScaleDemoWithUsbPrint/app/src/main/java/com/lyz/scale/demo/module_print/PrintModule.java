package com.lyz.scale.demo.module_print;

import android.content.Context;

import android_serialport_api.SerialPort;

/**
 * used for print module.
 */

public class PrintModule {
    private static final String TAG = "MainPrintLog";

    private Context context;

    private PrintModule(Context context) throws Exception {
        this.context = context;
    }

    private static PrintModule singleton = null;

    /// <summary>
    /// 单件模式
    /// </summary>
    public static PrintModule Instance(Context context) throws Exception {
        if (singleton == null) {
            singleton = new PrintModule(context);

        }
        return singleton;
    }

    /// <summary>
    /// 打印指令
    /// </summary>
    /// <param name="cmd"></param>
    /// <returns></returns>
    public void SendPrintCMD(String cmd) throws Exception {
        if (SerialPortUtilForPrint.mSerialPort != null && SerialPortUtilForPrint.isOpen) {
            synchronized (SerialPort.LOCK_ForPrint) {
                SerialPortUtilForPrint.mOutputStream.write(cmd.getBytes());
                }
            }
    }
}
