package com.lyz.scale.demo.print;

/**
 * Created by Administrator
 *
 * @author 猿史森林
 *         Date: 2017/11/30
 *         Class description:
 */
public enum PrinterCommand {
    /**
     * ESC指令
     */
    ESC,
    /**
     * TSC指令
     */
    TSC,
    /**
     * CPCL指令
     */
    CPCL
}
