package com.lyz.scale.demo.activity;

import android.app.Application;
import android.content.Context;

import com.lyz.scale.demo.common.CrashHandler;

/**
 * Created by liuyuzhi on 2018/8/4.
 */

public class BaseApplication extends Application {

    public static Context AppContext;

    @Override
    public void onCreate() {
        super.onCreate();

        AppContext = this;
        CrashHandler crashHandler= CrashHandler.getsInstance();
        crashHandler.init(this);
    }
}
